export const selectCurrentUser = (state) => {
  return state.user.currentUser;
};
