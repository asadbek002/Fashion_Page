export const light = {
  name: "light",
  colors: {
    background: "#fff",
    color: "#000",
  },
};

export const dark = {
  name: "dark",
  colors: {
    color: "#fff",
    background: "#000",
  },
};
